plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.example.moedade1real"; compileSdk = 36
    defaultConfig { applicationId = "com.example.moedade1real"; minSdk = 23; targetSdk = 36; versionCode = 1; versionName = "1.0" }
}
dependencies { implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.appcompat:appcompat:1.7.0") }
