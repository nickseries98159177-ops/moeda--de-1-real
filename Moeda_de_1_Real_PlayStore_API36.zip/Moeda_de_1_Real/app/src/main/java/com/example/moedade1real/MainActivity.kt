package com.example.moedade1real
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.widget.TextView
import android.widget.FrameLayout

class MainActivity: Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.WHITE)
        val title = TextView(this).apply {
            text = "MOEDA DE 1 REAL"
            textSize = 24f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER
        }
        root.addView(title, FrameLayout.LayoutParams(-1, 90).apply { gravity = Gravity.TOP })
        val coin = TextView(this).apply {
            text = "R$\n1"
            textSize = 64f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(120,85,10))
            setBackgroundColor(Color.rgb(235,235,235))
        }
        root.addView(coin, FrameLayout.LayoutParams(230,230).apply { gravity = Gravity.CENTER })
        val result = TextView(this).apply {
            text = ""; textSize = 42f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(120,85,10))
        }
        root.addView(result, FrameLayout.LayoutParams(-1,120).apply { gravity = Gravity.BOTTOM })
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                result.text = "R$ 1,00  🪙"
            }
            true
        }
        setContentView(root)
    }
}